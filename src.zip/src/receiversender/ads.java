package receiversender;

import java.io.File;
import java.io.IOException;


public class ads {
	public static void main(String[] args) {
		
		FileSender ft = new FileSender();
		ft.send("hallo.txt");
		
	}
}
